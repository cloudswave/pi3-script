# -*- coding: utf-8 -*-
# default.py
import urllib,urllib2,re,xbmcplugin,xbmcgui,subprocess,sys,os,os.path,sys,xbmcaddon,xbmcvfs,random,hashlib,threading,httplib,ssl,socket
import json,cookielib,gzip,time
import xbmc


from bt import TorrentFile
from xbmcswift2 import Plugin, CLI_MODE, xbmcaddon,ListItem,actions
from StringIO import StringIO
from zhcnkbd import Keyboard

reload(sys)
sys.setdefaultencoding('utf-8')

__addonid__ = "plugin.video.115"
__addon__ = xbmcaddon.Addon(id=__addonid__)
__cwd__ = __addon__.getAddonInfo('path')
__resource__  = xbmc.translatePath( os.path.join( __cwd__, 'lib' ) )
__subpath__  = xbmc.translatePath( os.path.join( __cwd__, 'subtitles') ).decode("utf-8")
if not os.path.exists(__subpath__):
	os.makedirs(__subpath__)
sys.path.append (__resource__)
sys.path.append (xbmc.translatePath( os.path.join(__resource__,'nova') ))


colors = {'back': '7FFF00','dir': '8B4513','video': 'FF0000','next': 'CCCCFF','bt': '33FF00', 'audio': '0000FF', 'subtitle':'505050', 'image': '00FFFF', '-1':'FF0000','0':'8B4513','1':'CCCCFF','2':'7FFF00', 'menu':'FFFF00', 'star1':'FFFF00','star0':'777777'}

ALL_VIEW_CODES = {
	'list': {
		'skin.confluence': 50, # List
		'skin.aeon.nox': 50, # List
		'skin.droid': 50, # List
		'skin.quartz': 50, # List
		'skin.re-touched': 50, # List
	},
	'thumbnail': {
		'skin.confluence': 500, # Thumbnail
		'skin.aeon.nox': 500, # Wall
		'skin.droid': 51, # Big icons
		'skin.quartz': 51, # Big icons
		'skin.re-touched': 500, #Thumbnail
		'skin.confluence-vertical': 500,
		'skin.jx720': 52,
		'skin.pm3-hd': 53,
		'skin.rapier': 50,
		'skin.simplicity': 500,
		'skin.slik': 53,
		'skin.touched': 500,
		'skin.transparency': 53,
		'skin.xeebo': 55,
	},
}

plugin = Plugin()
ppath = plugin.addon.getAddonInfo('path')
videoexts=plugin.get_setting('videoext').lower().split(',')
musicexts=plugin.get_setting('musicext').lower().split(',')

cookiefile = os.path.join(ppath, 'cookie.dat')
subcache = plugin.get_storage('subcache')
#filters = plugin.get_storage('ftcache', TTL=1440)

#urlcache = plugin.get_storage('urlcache', TTL=5)
setthumbnail=plugin.get_storage('setthumbnail')
setthumbnail['set']=False


class QRShower(xbmcgui.WindowDialog):
	def __init__(self):
		# width=self.getWidth()
		# height=self.getHeight()
		imgsize=360
		bkimg  = xbmc.translatePath( os.path.join( __cwd__, 'select-bg.png') ).decode("utf-8")
		bkimgControl = xbmcgui.ControlImage(0,0,1280,720, filename = bkimg)
		self.addControl(bkimgControl)
		self.imgControl = xbmcgui.ControlImage((1280-imgsize)/2, (720-imgsize)/2,imgsize, imgsize, filename = '')
		self.addControl(self.imgControl)
		self.labelControl = xbmcgui.ControlLabel((1280-imgsize)/2, (720+imgsize)/2 + 10, imgsize, 10, '请用115手机客户端扫描二维码', alignment = 0x00000002)
		self.addControl(self.labelControl)

	def showQR(self, url):
		socket = urllib.urlopen( url )
		pngdata = socket.read()
		qrfilepath=xbmc.translatePath( os.path.join( __cwd__, 'qr.png') ).decode("utf-8")
		with open(qrfilepath, "wb") as qrFile:
			qrFile.write(pngdata)
		qrFile.close()
		self.imgControl.setImage(qrfilepath)
		self.doModal()
		
	def changeLabel(self, label):
		self.labelControl.setLabel(label)        
	def onAction(self,action):
	
		self.close()
	def onClick(self, controlId):
	
		self.close()
		
class api_115(object):
	
	bad_servers = ['fscdnuni-vip.115.com', 'fscdntel-vip.115.com','cdnuni.115.com']
	def __init__(self, cookiefile):
		
		servers = {'0':'vipcdntel.115.com', '1':'mzvipcdntel.115.com', '2':'vipcdnuni.115.com', '3':'mzvipcdnuni.115.com', '4':'vipcdnctt.115.com','5':'mzvipcdnctt.115.com', '6':'vipcdngwbn.115.com','7':'vipcdn.115.com','8':'cdn.115.com'}		
		self.prefer_server = servers.get(plugin.get_setting('prefer115server'))
		self.cookiejar = cookielib.LWPCookieJar()
		if os.path.exists(cookiefile):
			self.cookiejar.load(
				cookiefile, ignore_discard=True, ignore_expires=True)
		self.opener = urllib2.build_opener(
			urllib2.HTTPCookieProcessor(self.cookiejar))

		self.headers = {
			'User-Agent': 'Mozilla / 5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36 115Browser/6.0.0',
			'Accept-encoding': 'gzip,deflate',
		}

	def login(self):
		try:
			login_page = self.urlopen('http://fspassport.115.com/?ct=login&ac=qrcode_token&is_ssl=1')
			msgs=json.loads(self.fetch(login_page))
			uid,_t,sign=msgs['uid'],msgs['time'],msgs['sign']
			
			sessionid_page=self.urlopen('http://msg.115.com/proapi/anonymous.php?ac=signin&user_id='+str(uid)+'&sign='+str(sign)+'&time='+str(_t))
			sessionmsgs=json.loads(self.fetch(sessionid_page))
			sessionid=sessionmsgs['session_id']
			imserver = sessionmsgs['server']
		except:
			return {'state':False, 'message':'Login Error'}
		qrcode_url='http://dgqrcode.115.com/api/qrcode.php?qrfrom=1&&uid='+str(uid)+'&_t='+str(time.time())
		
		qrShower = QRShower()
		#qrShower.showQR(qrcode_url)
		qthread = threading.Thread(target=qrShower.showQR, args=(qrcode_url,))
		qthread.start()
		
		for i in range(2):
			try:
				data = self.urlopen('http://'+imserver+'/chat/r?VER=2&c=b0&s='+str(sessionid)+'&_='+str(long(time.time())))
			except Exception, e:
				qrShower.close()
				qthread.join()
				return {'state':False, 'message':'Login Error'}
			ll = json.loads(self.fetch(data))
			#ll = eval(data)
			#ll = json.loads(data[data.index('[{'):])
			for l in ll:
				for p in l['p']:
					if p.has_key('key') == False:
						#qrShower.changeLabel('请在手机客户端点击登录确认')
						continue
					key = p['key']
					v = p['v']
					break;
		if key is None:
			return {'state':False, 'message':'Login Error'}
		qrShower.close()
		qthread.join()
		try:
			data = self.urlopen('http://fspassport.115.com/?ct=login&ac=qrcode&key=' + key + '&v=' + v)
			data = self.fetch(data)

			data = self.urlopen('http://passport.115.com/?ct=ajax&ac=islogin&is_ssl=1&_=' + str(time.time()))
			data = self.fetch(data)
			data = json.loads(data[data.index('{'):])
			if data['state'] != True:
				return {'state':False, 'message':data['msg']}
			if data['data'].has_key('USER_NAME'):
				self.user_name = data['data']['USER_NAME']
			else:
				self.user_name = data['data']['USER_ID']
			self.is_vip='0'
			if data['data'].has_key('IS_VIP'):
				self.is_vip=data['data']['IS_VIP']
			self.cookiejar.save(cookiefile, ignore_discard=True)
			return {'state':True, 'user_name':self.user_name,'is_vip':self.is_vip}
		except:
			return {'state':False, 'message':'Login Error'}
			
	def urlopen(self, url, **args): 
		#plugin.log.error(url)
		if 'data' in args and type(args['data']) == dict:
			args['data'] = json.dumps(args['data'])
			self.headers['Content-Type'] = 'application/json'
		else:
			self.headers['Content-Type'] = 'application/x-www-form-urlencoded'
		try:
			rs = self.opener.open(
				urllib2.Request(url, headers=self.headers, **args), timeout=60)
			return rs
		except:
			return ''
		
	def fetch(self,wstream):
		if wstream.headers.get('content-encoding', '') == 'gzip':
			content = gzip.GzipFile(fileobj=StringIO(wstream.read())).read()
		else:
			content = wstream.read()
		return content

	def getcookieatt(self, domain, attr):
		if domain in self.cookiejar._cookies and attr in \
		   self.cookiejar._cookies[domain]['/']:
			return self.cookiejar._cookies[domain]['/'][attr].value
	def depass(self,ac,ps,co):
		eac=hashlib.sha1(ac).hexdigest()
		eps=hashlib.sha1(ps).hexdigest()
		return hashlib.sha1(hashlib.sha1(eps+eac).hexdigest()+co.upper()).hexdigest()
	def encodes(self):
		prefix = ""
		phpjs=int(random.random() * 0x75bcd15)
		retId = prefix
		retId += self.encodess(int(time.time()),8)
		retId += self.encodess(phpjs, 5)
		return retId
	def encodess(self,seed, reqWidth):
		seed = hex(int(seed))[2:]
		if (reqWidth < len(seed)):
			return seed[len(seed) - reqWidth:]
		if (reqWidth >  len(seed)):
			return (1 + (reqWidth - seed.length)).join('0') + seed
		return seed	
		
		
xl = api_115(cookiefile)

		
@plugin.route('/login')
def login():
	r=xl.login()
	if r['state']:
		plugin.notify(msg='登录成功')
	else:
		plugin.notify('登录失败：' + r['message'])
	return

@plugin.route('/setting')
def setting():
	ret= plugin.open_settings()
	return


@plugin.route('/')
def index():
	try:
		data=xl.urlopen('http://web.api.115.com/files?aid=0&cid=0&o=user_ptime&asc=0&offset=0&show_dir=1&limit=115&code=&scid=&snap=0&natsort=1&source=&format=json')
		data= xl.fetch(data).replace('\n','').replace('\r','')
		data=json.loads(data[data.index('{'):])
		if not data['state']:
			login()
	except:
		plugin.notify(msg='检测登录失败')
	items = [
		{'label': '网盘文件', 'path': plugin.url_for('getfile',cid='0',offset=0,star='0'),'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'icon.png') ).decode("utf-8")},
		{'label': '星标列表', 'path': plugin.url_for('getfile',cid='0',offset=0,star='1'),'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'star.png') ).decode("utf-8")},
		#{'label': '记事本', 'path': plugin.url_for('note',cid='0',offset=0)},
		{'label': '离线任务列表', 'path': plugin.url_for('offline_list')},
		{'label': '网盘搜索', 'path': plugin.url_for('search',mstr='0',offset=0)},
		{'label': '磁力搜索', 'path': plugin.url_for('btsearchInit',sstr='0', modify='0'),'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8")},		
		{'label': '豆瓣标签', 'path': plugin.url_for('dbmovie',tags='0',sort='recommend',page='0',addtag='1'),'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'douban.png') ).decode("utf-8")},
		{'label': '豆瓣电影搜索', 'path': plugin.url_for('dbactor', sstr='none', page=0)},
		{'label': '豆瓣排行榜', 'path': plugin.url_for('dbtops')},
		
		{'label': '扫码登入', 'path': plugin.url_for('login'),'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'scan.png') ).decode("utf-8")},
		{'label': '设置', 'path': plugin.url_for('setting'),'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'setup.png') ).decode("utf-8")},
	]
	
	if str(plugin.get_setting('javbus'))=='true':
		items.insert(8, {'label': 'javbus', 'path': plugin.url_for('javbus')})
	sortasc=str(plugin.get_setting('sortasc'))
	setthumbnail['set']=True
	return items


@plugin.route('/search/<mstr>/<offset>')
def search(mstr,offset):
	if not mstr or mstr=='0':
		kb = Keyboard('',u'请输入搜索关键字')
		kb.doModal()
		if not kb.isConfirmed():
			return
		mstr = kb.getText()
		if not mstr:
			return
	sorttypes = {'0': 'user_ptime','1': 'file_size','2': 'file_name'}
	sorttype=sorttypes[plugin.get_setting('sorttype')]	
	sortasc=str(plugin.get_setting('sortasc'))
	pageitems = {'0': '25','1': '50','2': '100'}
	pageitem=pageitems[plugin.get_setting('pageitem')]	
	url='http://web.api.115.com/files/search?search_value=' + urllib.quote_plus(mstr) + '&type=&star=0&o='+sorttype+'&asc='+sortasc+'&offset='+str(offset)+'&show_dir=1&natsort=1&limit='+str(pageitem)+'&format=json'
	try:
		data=xl.urlopen(url)
		data= xl.fetch(data).replace('\n','').replace('\r','')
		data=json.loads(data[data.index('{'):])
		
		videoexts=plugin.get_setting('videoext').lower().split(',')
		musicexts=plugin.get_setting('musicext').lower().split(',')
		
		if data['state']:
			playlistvideo = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
			playlistvideo.clear()
			imagecount=0
			items=[]
			for item in data['data']:
				listitem=getListItem(item)
				if listitem!=None:
					items.append(listitem)
					if listitem.playable:
						playlistvideo.add(listitem.get_path(), listitem.as_xbmc_listitem())
					if item.has_key('ms'):
						imagecount+=1
			if data['count']>int(offset)+int(pageitem):
				items.append({'label': colorize_label('下一页', 'next'), 
					'path': plugin.url_for('search',mstr=mstr,offset=str(int(offset)+int(pageitem))),
					'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
			#skindir=xbmc.getSkinDir()
			if imagecount >= 10 and imagecount * 2 > len(items):       
				setthumbnail['set']=True
				#if ALL_VIEW_CODES['thumbnail'].has_key(skindir):
				#	plugin.set_view_mode(ALL_VIEW_CODES['thumbnail'][skindir])
			return items
		else:
			plugin.notify(msg='网盘搜索失败,错误信息:'+str(data['error']))
			return
	except:
		plugin.notify(msg='数据获取失败')
		return


def getListItem(item):
	context_menu_items=[]
	
	if item.has_key('sha'):
		if item.has_key('iv'):
			isiso='1'
			if item.has_key('vdi'):
				if item['vdi']>=1:
					isiso='0'
			
			listitem=ListItem(label=colorize_label(item['n'], 'video'), label2=None, icon=None, thumbnail=None, path=plugin.url_for('play',pc=item['pc'],name=item['n'].encode('UTF-8'),iso=isiso))
			listitem.set_info('video', {'size': item['s']})
			listitem.playable=True

		elif item.has_key('ms'):			
			listitem=ListItem(label=colorize_label(item['n'], 'image'), label2=None, icon=None, thumbnail=None, path=plugin.url_for('playimg',pc=item['pc'],name=item['n'].encode('UTF-8')))
			listitem.set_info('image', {'size': item['s']})
			listitem.playable=True

		elif item['ico'] in videoexts:
			listitem=ListItem(label=colorize_label(item['n'], 'video'), label2=None, icon=None, thumbnail=None, path=plugin.url_for('play',pc=item['pc'],name=item['n'].encode('UTF-8'),iso='1'))
			listitem.set_info('video', {'size': item['s']})
			listitem.set_is_playable('true')

		elif  item['ico'] in musicexts:
			listitem=ListItem(label=colorize_label(item['n'], 'audio'), label2=None, icon=None, thumbnail=None, path=plugin.url_for('play',pc=item['pc'],name=item['n'].encode('UTF-8'),iso='1'))
			listitem.set_info('audio', {'size': item['s']})
			listitem.playable=True

		elif item['ico']=='torrent':
			listitem=ListItem(label=colorize_label(item['n'], 'bt'), label2=None, icon=None, thumbnail=None, path=plugin.url_for('offline_bt',sha1=item['sha']))
			listitem.playable=True
		else:
			listitem=None
			
		if is_subtitle(item['ico']):
			subcache[item['n'].encode('UTF-8')]=item['pc']
		
		if item.has_key('u') and  listitem!=None:
			listitem.set_thumbnail(item['u'])
		
			
		if listitem!=None and item.has_key('cid') and item.has_key('fid'):
			warringmsg='是否删除文件:'+item['n'].encode('UTF-8')
			deleteurl=plugin.url_for('deletefile',pid=item['cid'],fid=item['fid'],warringmsg=warringmsg)
			context_menu_items.append(('删除', 'RunPlugin('+deleteurl+')',))
	else:
		listitem=ListItem(label=colorize_label(item['n'], 'dir'), label2=None, icon=None, thumbnail=None, path=plugin.url_for('getfile',cid=item['cid'],offset=0,star='0'))
		if item.has_key('cid') and item.has_key('pid'):
			warringmsg='是否删除目录及其下所有文件:'+item['n'].encode('UTF-8')
			#listitem.add_context_menu_items([('删除', 'RunPlugin('+plugin.url_for('deletefile',pid=item['pid'],fid=item['cid'],warringmsg=warringmsg)+')',)],False)
			deleteurl=plugin.url_for('deletefile',pid=item['pid'],fid=item['cid'],warringmsg=warringmsg)
			context_menu_items.append(('删除', 'RunPlugin('+deleteurl+')',))
			
	if item.has_key('m') and  listitem!=None:
		listitem.set_property('is_mark',str(item['m']))
		listitem.label=colorize_label('★', 'star'+str(item['m']))+listitem.label
		if item.has_key('fid'):
			fid=item['fid']
		else:
			fid=item['cid']
		if str(item['m'])=='0':
			#listitem.add_context_menu_items([('星标', 'RunPlugin('+plugin.url_for('mark',fid=fid,mark='1')+')',)],False)
			context_menu_items.append(('星标', 'RunPlugin('+plugin.url_for('mark',fid=fid,mark='1')+')',))
		else:
			#listitem.add_context_menu_items([('取消星标', 'RunPlugin('+plugin.url_for('mark',fid=fid,mark='0')+')',)],False)
			context_menu_items.append(('取消星标', 'RunPlugin('+plugin.url_for('mark',fid=fid,mark='0')+')',))
	if len(context_menu_items)>0:
		listitem.add_context_menu_items(context_menu_items,False)
	return listitem

@plugin.route('/deletefile/<pid>/<fid>/<warringmsg>')
def deletefile(pid,fid,warringmsg):
	dialog = xbmcgui.Dialog()
	ret = dialog.yesno('删除警告', warringmsg)
	if ret:
		try:
			data = urllib.urlencode({'pid': pid,'fid':fid})	
			data=xl.urlopen('http://web.api.115.com/rb/delete',data=data)
			data= xl.fetch(data).replace('\n','').replace('\r','')
			data=json.loads(data[data.index('{'):])
			#plugin.notify(data,delay=50000)
			if data['state']:
				xbmc.executebuiltin('Container.Refresh()')
			else:
				plugin.notify(msg='删除失败,错误信息:'+str(data['error']))
				return
		except:
			plugin.notify(msg='删除失败')
			return


@plugin.route('/mark/<fid>/<mark>')
def mark(fid,mark):
	data = urllib.urlencode({'fid': fid,'is_mark':mark})
	try:
		data=xl.urlopen('http://web.api.115.com/files/edit',data=data)
		data= xl.fetch(data).replace('\n','').replace('\r','')
		data=json.loads(data[data.index('{'):])
		if data['state']:
			xbmc.executebuiltin('Container.Refresh()')
		else:
			plugin.notify(msg='星标失败,错误信息:'+str(data['error']))
			return
	except:
			plugin.notify(msg='星标失败')
			return

@plugin.route('/getfile/<cid>/<offset>/<star>')
def getfile(cid,offset,star):
	subcache.clear()
	sorttypes = {'0': 'user_ptime','1': 'file_size','2': 'file_name'}
	sorttype=sorttypes[plugin.get_setting('sorttype')]	
	sortasc=str(plugin.get_setting('sortasc'))
	pageitems = {'0': '25','1': '50','2': '100'}
	pageitem=pageitems[plugin.get_setting('pageitem')]	
	
	if sorttype=='file_name':
		data=xl.urlopen('http://aps.115.com/natsort/files.php?aid=1&cid='+str(cid)+'&type=&star='+star+'&o='+sorttype+'&asc='+sortasc+'&offset='+str(offset)+'&show_dir=1&limit='+pageitem+'&format=json'+'&_='+str(long(time.time())))
	else:
		data=xl.urlopen('http://web.api.115.com/files?aid=1&cid='+str(cid)+'&type=&star='+star+'&o='+sorttype+'&asc='+sortasc+'&offset='+str(offset)+'&show_dir=1&limit='+pageitem+'&format=json'+'&_='+str(long(time.time())))
	data= xl.fetch(data).replace('\n','').replace('\r','')
	data=json.loads(data[data.index('{'):])
	if data['state']:
		#playlistvideo = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
		#playlistvideo.clear()
		
		imagecount=0
		items=[]
		for item in data['path']:
			if item['cid']!=0 and item['cid']!=cid:
				items.append({'label': colorize_label('返回到【'+item['name']+"】", 'back'), 'path': plugin.url_for('getfile',cid=item['cid'],offset=0,star='0')})		
		for item in data['data']:			
			listitem=getListItem(item)			
			if listitem!=None:
				#if listitem.playable:
					#playlistvideo.add(listitem.get_path(), listitem.as_xbmc_listitem())
				items.append(listitem)					
				if item.has_key('ms'):
					imagecount+=1
		if data['count']>int(offset)+int(pageitem):
			items.append({'label': colorize_label('下一页', 'next'),
				'path': plugin.url_for('getfile',cid=cid,offset=str(int(offset)+int(pageitem)),star=star),
				'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
			#urlcache[cid+"/"+offset+"/"+str(star)] = items
		#xbmc.executebuiltin('Container.SetViewMode(8)')
		#skindir=xbmc.getSkinDir()
		if imagecount >= 10 and imagecount * 2 > len(items):
			setthumbnail['set']=True
			#plugin.notify('setthumbnail')
			#if ALL_VIEW_CODES['thumbnail'].has_key(skindir):
			#	plugin.set_view_mode(ALL_VIEW_CODES['thumbnail'][skindir])
		return items
	else:
		plugin.notify(msg='数据获取失败,错误信息:'+str(data['error']))
		return


@plugin.route('/playiso/<pc>/<name>')
def playiso(pc,name):
	videourl=get_file_download_url(pc)
	xbmc.executebuiltin("PlayMedia(%s)" % (videourl))
	return


@plugin.route('/playimg/<pc>/<name>')
def playimg(pc,name):
	data=xl.urlopen('http://web.api.115.com/files/image?pickcode='+pc+'&_='+str(long(time.time())))		
	data=json.loads(xl.fetch(data))
	imageurl=''
	if data['state']:
		imageurl=data['data']['source_url']
	xbmc.executebuiltin("ShowPicture(%s)" % (imageurl))
	return


def rmtree(path):
	if isinstance(path, unicode):
		path = path.encode('utf-8')
	dirs, files = xbmcvfs.listdir(path)
	for dir in dirs:
		rmtree(os.path.join(path, dir))
	for file in files:
		xbmcvfs.delete(os.path.join(path, file))
	xbmcvfs.rmdir(path)

@plugin.route('/play/<pc>/<name>/<iso>')
def play(pc,name,iso):
	stm=str(plugin.get_setting('select'))
	if iso=='1':
		stm='5'	
	sub_pcs={}
	#qtyps=[]
	
	data=xl.urlopen('http://web.api.115.com/files/video?pickcode='+pc+'&_='+str(long(time.time())))	
	data= xl.fetch(data).replace('\n','').replace('\r','')
	data=json.loads(data[data.index('{'):])
	if data['state']:
		# for definition in data['definition_list']:
			# plugin.notify(data['definition_list'][definition])
			#if definition=='800000': qtyps.append('标清':'1')
		if data.has_key('subtitle_info'):
			for s in data['subtitle_info']:
				sub_pcs[('_内置_'+s['title']).decode('utf-8')]=s['url']
		
	if stm=='0':
		
		dialog = xbmcgui.Dialog()
		qtyps = [('标清', '1'),('高清', '2'), ('蓝光', '3'),('1080p', '4'),('原码', '5')]
		#qtyps.append('原码':'5')
		sel = dialog.select('清晰度', [q[0] for q in qtyps])
		if sel is -1: return 'cancel'
		stm=str(sel+1)		
	
	if stm=='5':
		videourl=get_file_download_url(pc,isvideo=True)
		if videourl=='':
			plugin.notify(msg='无视频文件.')
			return
	else:
		data=xl.urlopen('http://115.com/api/video/m3u8/'+pc+'.m3u8')
		data=xl.fetch(data)
		url= re.compile(r'http:(.*?)\r', re.DOTALL).findall(data)
		if len(url)<1:
			plugin.notify(msg='无视频文件.')
			return
		if len(url)<int(stm):
			stm=str(len(url))
		videourl='http:'+url[int(stm)-1]
	
	subpath=''
	#if iso=='0':
	name=name[:name.rfind('.')]		
	
	for k,v in subcache.items():
		if k.find(name)!= -1:
			sub_pcs['_同目录_'+k]=get_file_download_url(v)
			
	if plugin.get_setting('subtitle')=='true':
		try:
			uid = xl.getcookieatt('.115.com', 'UID')
			uid = uid[:uid.index('_')]
			data=xl.urlopen('http://web.api.115.com/movies/subtitle?pickcode='+pc)
			data=json.loads(xl.fetch(data))		
			if data['state']:
				for s in data['data']:
					sub_pcs[(s['language']+'_'+s['filename']).decode('utf-8')]=s['url']
		except:
			pass
				
	if len(sub_pcs)==1:
		subpath = os.path.join( __subpath__,sub_pcs.keys()[0].decode('utf-8'))
		suburl=sub_pcs[sub_pcs.keys()[0]]
		plugin.notify('加载了1个字幕')
		
	elif len(sub_pcs)>1:
		dialog = xbmcgui.Dialog()
		sel = dialog.select('字幕选择', [subname for subname in sub_pcs.keys()])
		if sel>-1: 
			subpath = os.path.join( __subpath__,sub_pcs.keys()[sel])
			suburl = sub_pcs[sub_pcs.keys()[sel]]
			
	if subpath!='':
		if suburl!='':	
			socket = urllib.urlopen( suburl )
			subdata = socket.read()
			with open(subpath, "wb") as subFile:
				subFile.write(subdata)
			subFile.close()
	plugin.set_resolved_url(videourl,subpath)
	return


@plugin.route('/offline_bt/<sha1>')
def offline_bt(sha1):
	dialog = xbmcgui.Dialog()
	ret = dialog.yesno('115网盘提示', '是否离线文件?')
	if ret:
		uid = xl.getcookieatt('.115.com', 'UID')
		uid = uid[:uid.index('_')]
		data=xl.urlopen('http://115.com/?ct=offline&ac=space&_='+str(long(time.time())))
		data=json.loads(xl.fetch(data))
		sign=data['sign']
		_time=data['time']
		data = urllib.urlencode({'sha1': sha1,'uid':uid,'sign':sign,'time':_time})
		data=xl.urlopen('http://115.com/web/lixian/?ct=lixian&ac=torrent',data=data)		
		data=json.loads(xl.fetch(data))
		if data['state']:			
			wanted='0'
			for i in range(1,len(data['torrent_filelist_web'])):
				wanted+='%02C'
				wanted+=str(i)			
			torrent_name=data['torrent_name']			
			info_hash=data['info_hash']			
			data = urllib.urlencode({'info_hash': info_hash,'wanted': wanted,'savepath': torrent_name,'uid':uid,'sign':sign,'time':_time})
			
			data=xl.urlopen('http://115.com/web/lixian/?ct=lixian&ac=add_task_bt',data=data)
			data=json.loads(xl.fetch(data))
			if data['state']:
				plugin.notify('离线任务添加成功！', delay=2000)
			else:
				plugin.notify(data['error_msg'], delay=2000)
				return
		else:
			plugin.notify(data['error_msg'], delay=2000)
			return			
	else:
		return


def get_file_download_url(pc,isvideo=False):
	bad_server = ''
	result = ''
	data=xl.urlopen("http://web.api.115.com/files/download?pickcode="+pc+"&_="+str(long(time.time())))		
	data=json.loads(xl.fetch(data))
	if data['state']:
		result=data['file_url']
	else:
		data=xl.urlopen("http://proapi.115.com/app/chrome/down?method=get_file_url&pickcode="+pc)
		data=json.loads(xl.fetch(data))
		if data['state']:			
			for value in data['data'].values():				
				if value.has_key('url'):
					result = value['url']['url']
					break
		else:
			return ''      
			
	# for bs in xl.bad_servers:
		# if result.find(bs) != -1:
			# bad_server = bs
			# break
	# if bad_server != '':
		# result = result.replace(bad_server, xl.prefer_server)
	
	oldcdn=result[7:result.find('/',8)]
	dialog = xbmcgui.Dialog()
	if isvideo:
		serverchange=str(plugin.get_setting('serverchange'))
		if serverchange=='0':
			if dialog.yesno('线路选择', '更改为服务商线路'): serverchange='1'
		if serverchange=='1':
			result = re.sub('(http://)(.*115.com)(.*)', r'\1'+xl.prefer_server+r'\3', result)
			plugin.notify('CDN服务器：由'+oldcdn+'改到'+xl.prefer_server)
		else:
			plugin.notify('CDN服务器：'+oldcdn)
	return result


@plugin.route('/delete_offline_list/<hashinfo>/<warringmsg>')
def delete_offline_list(hashinfo,warringmsg):
	dialog = xbmcgui.Dialog()
	ret = dialog.yesno('离线任务删除', warringmsg)
	if ret:
		data=xl.urlopen("http://115.com/web/lixian/?ct=lixian&ac=task_del",data=hashinfo)
		data=xl.fetch(data)
		data=json.loads(data[data.index('{'):])
		
		if data['state']:			
			xbmc.executebuiltin('Container.Refresh()')
		else:
			plugin.notify(msg='删除失败,错误信息:'+str(data['error']))
			return


@plugin.route('/offline_list')
def offline_list():
	msg_st={'-1': '任务失败','0': '任务停止','1': '下载中','2': '下载完成'}
	data=xl.urlopen("http://115.com/?ct=offline&ac=space&_="+str(time.time()))
	data=xl.fetch(data)
	data=json.loads(data[data.index('{'):])
	sign=data['sign']
	_time=data['time']
	uid = xl.getcookieatt('.115.com', 'UID')
	uid = uid[:uid.index('_')]
	page=1
	task=[]
	items=[]
	while True:
		data = urllib.urlencode({'page': str(page),'uid':uid,'sign':sign,'time':_time})
		data=xl.urlopen("http://115.com/web/lixian/?ct=lixian&ac=task_lists",data=data)
		data=xl.fetch(data)
		data=json.loads(data[data.index('{'):])
		if data['state'] and data['tasks']:
			for item in data['tasks']:
				task.append(item)
			if data['page_count']>page:
				page=page+1
			else:
				break
		else:
			break
	
	clearcomplete={'time':_time,'sign':sign,'uid':uid}
	clearfaile={'time':_time,'sign':sign,'uid':uid}
	i=0
	j=0
	
	for item in task:
		if item['status']==2 and item['move']==1:
			clearcomplete['hash['+str(i)+']']=item['info_hash']
			i+=1
		if item['status']==-1:
			clearfaile['hash['+str(j)+']']=item['info_hash']
			j+=1
		
		listitem=ListItem(label=item['name']+colorize_label("["+msg_st[str(item['status'])]+"]", str(item['status'])), label2=None, icon=None, thumbnail=None, path=plugin.url_for('getfile',cid=item['file_id'],offset='0',star='0'))
		_hash = urllib.urlencode({'uid':uid,'sign':sign,'time':_time,r'hash[0]': item['info_hash']})		
		listitem.add_context_menu_items([('删除离线任务', 'RunPlugin('+plugin.url_for('delete_offline_list',hashinfo=_hash,warringmsg='是否删除任务')+')',)],False)
		
		items.append(listitem)
	if j>0:
		_hash = urllib.urlencode(clearfaile)
		items.insert(0, {
			'label': colorize_label('清空失败任务','-1'),
			'path': plugin.url_for('delete_offline_list',hashinfo=_hash,warringmsg='是否清空'+str(j)+'个失败任务')})
	if i>0:
		_hash = urllib.urlencode(clearcomplete)
		items.insert(0, {
			'label': colorize_label('清空完成任务','2'),
			'path': plugin.url_for('delete_offline_list',hashinfo=_hash,warringmsg='是否清空'+str(i)+'个完成任务')})
	return items


@plugin.route('/lxlist/<cid>/<name>')
def lxlist(cid,name):
	dialog = xbmcgui.Dialog()
	ret = dialog.yesno('115网盘提示', '是否包含子文件夹?')
	lists=getlxlist(cid,ret)
	x=0
	#plugin.log.error(lists)
	if len(lists)>0:
		strs=name+'\n'
		for item in lists:
			strs += item['n']+"|115:"+item['pc']+"|"+item['u']+'\n'
			if len(strs)>40000:
				data = urllib.urlencode({'nid': '', 'content': strs, 'cid': '0'})		
				data=xl.urlopen("http://115.com/note/?ct=note&ac=save",data=data)
				x=x+1
				strs=name+"-"+str(x)+'\n'
		data = urllib.urlencode({'nid': '', 'content': strs, 'cid': '0'})		
		data=xl.urlopen("http://115.com/note/?ct=note&ac=save",data=data)
		data= xl.fetch(data).replace('\n','').replace('\r','')
		data=json.loads(data[data.index('{'):])
		#plugin.log.error(data)
		if data['state']:
			plugin.notify(msg='制作成功！')
		else:
			plugin.notify(msg='制作失败！'+str(data['msg']))


def getlxlist(cid,alls):
	sorttypes = {'0': 'user_ptime','1': 'file_size','2': 'file_name'}
	sorttype=sorttypes[plugin.get_setting('sorttype')]	
	sortasc=str(plugin.get_setting('sortasc'))
	lists=[]
	offsets=0
	if alls:
		while True:
			data=xl.urlopen("http://web.api.115.com/files?aid=1&cid="+cid+"&type=4&star=0&o="+sorttype+"&asc="+sortasc+"&offset="+str(offsets)+"&show_dir=1&limit=80&format=json")
			data= xl.fetch(data).replace('\n','').replace('\r','')
			data=json.loads(data[data.index('{'):])
			if data['state']:
				for item in data['data']:
					if item.has_key('sha'):
						if item.has_key('iv'):
							lists.append({'n':item['n'],'pc':item['pc'],'u':item['u']})
				if data['count']>data['offset']+80:
					offsets=data['offset']+80
				else:
					break;
			else:
				break;
		return lists
	else:
		while True:
			data=xl.urlopen("http://web.api.115.com/files?aid=1&cid="+cid+"&type=&star=0&o="+sorttype+"&asc="+sortasc+"&offset="+str(offsets)+"&show_dir=1&limit=80&format=json")
			data= xl.fetch(data).replace('\n','').replace('\r','')
			data=json.loads(data[data.index('{'):])
			if data['state']:
				for item in data['data']:
					if item.has_key('sha'):
						if item.has_key('iv'):
							lists.append({'n':item['n'],'pc':item['pc'],'u':item['u']})
				if data['count']>data['offset']+80:
					offsets=data['offset']+80
				else:
					break;
			else:
				break;
		return lists

@plugin.route('/offline/<url>')
def offline(url):
	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
	#xbmc.sleep(1000)
	data=xl.urlopen("http://115.com/?ct=offline&ac=space&_="+str(time.time()))
	data=xl.fetch(data)
	data=json.loads(data[data.index('{'):])
	sign=data['sign']
	#plugin.notify(sign)
	time1=data['time']
	uid = xl.getcookieatt('.115.com', 'UID')
	uid = uid[:uid.index('_')]
	data = urllib.urlencode({'url': url,'uid':uid,'sign':sign,'time':time1})
	data=xl.urlopen("http://115.com/web/lixian/?ct=lixian&ac=add_task_url",data=data)
	data=xl.fetch(data)
	#plugin.log.error(data)
	data=json.loads(data[data.index('{'):])
	if data['state']:
		plugin.notify(u' 添加离线成功'.encode('utf-8'),delay=1000)
	else:
		plugin.notify(u' 添加离线失败,错误代码:'.encode('utf-8')+data['error_msg'],delay=1000)
	xbmc.executebuiltin( "Dialog.Close(busydialog)" )
	if data['state']:
		return data['info_hash']
	else:
		return ''


@plugin.route('/offlinedown/<url>/<title>/<msg>')
def offlinedown(url,title='',msg=''):	
	dialog = xbmcgui.Dialog()
	ret = dialog.yesno('是否离线 '+title+'?', msg)
	if ret:
		info_hash=offline(url)
		if  info_hash:
			data=xl.urlopen("http://115.com/?ct=offline&ac=space&_="+str(time.time()))
			data=xl.fetch(data)
			data=json.loads(data[data.index('{'):])
			sign=data['sign']
			time1=data['time']
			uid = xl.getcookieatt('.115.com', 'UID')
			uid = uid[:uid.index('_')]
			page=1			
			file_id=''
			for i in range(0,20):
				time.sleep(1)
				data = urllib.urlencode({'page': str(page),'uid':uid,'sign':sign,'time':time1})
				data=xl.urlopen("http://115.com/web/lixian/?ct=lixian&ac=task_lists",data=data)
				data=xl.fetch(data)
				data=json.loads(data[data.index('{'):])
				if data['state']:
					curitem=None
					for item in data['tasks']:
						if item['info_hash']==info_hash:
							curitem=item
							break
					if curitem:
						if curitem['status']==2 and curitem['move']==1:
							if curitem.has_key('file_id'):
								file_id	=curitem['file_id']
					if file_id:
						break;
			if file_id:	
				return getfile(cid=file_id,offset=0,star='0')
			else:
				plugin.notify('离线任务未完成,请稍候从离线列表进入查看任务状态')


import nova2
@plugin.route('/btsearchInit/<sstr>/<modify>')
def btsearchInit(sstr='',modify='0'):
	if sstr=='0':sstr=''
	if not sstr or sstr=='0' or modify=='1':
		kb = Keyboard(sstr,u'请输入搜索关键字')
		kb.doModal()
		if not kb.isConfirmed():
			return
		sstr = kb.getText()
		#plugin.notify(sstr)
		if not sstr:
			return
	btenginelist=nova2.initialize_engines()
	#plugin.notify(len(btenginelist))
	items=[]
	items.append({'label': '编辑搜索关键字[COLOR FF00FFFF]%s[/COLOR]'%(sstr.encode('utf-8')),
						'path': plugin.url_for('btsearchInit', sstr=sstr.encode('utf-8'), modify='1'),
						'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8")})
	
	for btengine in btenginelist:
		if plugin.get_setting(btengine).lower()=='true':
			items.append({'label': '在[COLOR FFFFFF00]%s[/COLOR]搜索[COLOR FF00FFFF]%s[/COLOR]'%(btengine,sstr), 'path': plugin.url_for('btsearch',website=btengine,sstr=sstr,sorttype='-1',page='1')})
	return items

@plugin.route('/btsearch/<website>/<sstr>/<sorttype>/<page>')
def btsearch(website,sstr,sorttype,page):	
	if not sstr or sstr=='0':
		return
	items=[]
	result=nova2.enginesearch(website,sstr,sorttype,page)
	#plugin.notify(result['state'])
	if result['state']:
		if len(result['list'])<=0:
			plugin.notify('未找到磁力链接')
			return
		for res_dict in result['list']:
			title=res_dict['name'].encode('UTF-8')
			filemsg ='大小：'+res_dict['size'].encode('UTF-8')+'  创建时间：'+res_dict['date'].encode('UTF-8')
			listitem=ListItem(label=colorize_label(title, 'bt'), label2=res_dict['size'], icon=None, thumbnail=None, path=plugin.url_for('offlinedown',url=res_dict['link'].encode('UTF-8'),title=title,msg=filemsg))
			items.append(listitem)
		if result.has_key('nextpage'):
			if result['nextpage']:
				if result.has_key('sorttype'):
					sorttype=result['sorttype']
				items.append({'label': colorize_label('下一页', 'next'), 
					'path': plugin.url_for('btsearch',website=website,sstr=sstr,sorttype=str(sorttype),page=str(int(page)+1)),
					'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
		return items
	else:
		plugin.notify('磁力搜索取消或错误')
		return

opener = urllib2.build_opener()
def _http(url, data=None,referer=None):

	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
	req.add_header('Accept-encoding', 'gzip,deflate')
	req.add_header('Accept-Language', 'zh-cn')
	if referer:
		req.add_header('Referer', referer)
	if data:
		rsp = urllib2.urlopen(req, data=data, timeout=15)
	else:
		rsp = urllib2.urlopen(req, timeout=15)
	if rsp.info().get('Content-Encoding') == 'gzip':
		buf = StringIO(rsp.read())
		f = gzip.GzipFile(fileobj=buf)
		data = f.read()
	else:
		data = rsp.read()
	rsp.close()
	return data



@plugin.route('/dbsubject/<subject>')
def dbsubject(subject):
	menus=[]
	try:
		rsp = _http('http://api.douban.com/v2/movie/subject/'+subject)
		minfo = json.loads(rsp)
		year=minfo['year']
		strlist=[]
		strlist.append(minfo['title'])
		strlist.append(minfo['title']+' '+year)
		if minfo.has_key('original_title'):
			strlist.append(minfo['original_title'])
			strlist.append(minfo['original_title']+' '+year)
		if minfo.has_key('aka'):
			for aka in minfo['aka']:
				if aka.find('(')>=0 and  aka.find(')')>=0:
					aka=aka.replace(aka[ aka.find('('):aka.find(')')+1],'')
				strlist.append(aka)
				strlist.append(aka+' '+year)
		#去重
		news_strlist = list(set(strlist))
		news_strlist.sort(key=strlist.index)
		
		for sstr in news_strlist:
			listitem=ListItem(label='BT:[COLOR FF00FFFF]%s[/COLOR]' % (sstr.encode('utf-8')),
				label2=None, icon=None, thumbnail=xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8"),
				path=plugin.url_for('btsearchInit', sstr=sstr.encode('utf-8'), modify='0'))
			menus.append(listitem)
			
		if minfo.has_key('casts'):
			for cast in minfo['casts']:
				thumb=xbmc.translatePath( os.path.join( __cwd__, 'guest.png') ).decode("utf-8")
				if cast['avatars']:
					if cast['avatars']['medium']:
						thumb=cast['avatars']['medium']
				castname=cast['name'].encode('utf-8')
				menus.append({'label': '演员:[COLOR FFFF66AA]%s[/COLOR]' % (castname),
						'path':  plugin.url_for('dbactor', sstr=castname, page=0),
						'thumbnail':thumb})
		if minfo.has_key('directors'):
			for director in minfo['directors']:
				thumb=xbmc.translatePath( os.path.join( __cwd__, 'guest.png') ).decode("utf-8")
				if director['avatars']:
					if director['avatars']['medium']:
						thumb=director['avatars']['medium']
				directorname=director['name'].encode('utf-8')
				menus.append({'label': '导演:[COLOR FFFFAA66]%s[/COLOR]' % (directorname),
						'path':  plugin.url_for('dbactor', sstr=directorname, page=0),
						'thumbnail':thumb})
		return menus
	except:
		plugin.notify('获取影片信息失败')
		return

filters={}
@plugin.route('/dbtops')
def dbtops():
	item = [
		{'label': '豆瓣电影新片榜TOP10', 'path': plugin.url_for('dbntop')},
		{'label': '豆瓣电影TOP250', 'path': plugin.url_for('dbtop', page=0)},
		]
		
	types=[['剧情','11'] , ['喜剧','24'] , ['动作','5'] , ['爱情','13'] , ['科幻','17'] , ['动画','25'] , ['悬疑','10'] , ['惊悚','19'] , ['恐怖','20'] , ['纪录','1'] , ['短','23'] , ['情色','6'] , ['同性','26'] , ['音乐','14'] , ['歌舞','7'] , ['家庭','28'] , ['儿童','8'] , ['传记','2'] , ['历史','4'] , ['战争','22'] , ['犯罪','3'] , ['西部','27'] , ['奇幻','16'] , ['冒险','15'] , ['灾难','12'] , ['武侠','29'] , ['古装','30'] , ['运动','18'] , ['黑色影','31']]
	for type in types:
		item.append({'label': type[0]+'片排行', 'path': plugin.url_for('dbtypetop', type=type[1],start=0)})
		lable=type[0]
	return item

def dbgettag():
	filters['类型标签']=['剧情' , '喜剧' , '动作' , '爱情' , '科幻' , '动画' , '悬疑' , '惊悚' , '恐怖' ,
		'纪录片' , '短片' , '情色' , '同性' , '音乐' , '歌舞' , '家庭' , '儿童' , '传记' , '历史' , '战争' ,
		'犯罪' , '西部' , '奇幻' , '冒险' , '灾难' , '武侠' , '古装' , '运动' , '戏曲' , '黑色电影' ,'女性' , '史诗' , 'cult']
		
	filters['地区标签']=['美国' , '中国大陆' , '香港' , '台湾' , '日本' , '韩国' , '英国' , '法国' , '意大利' , '西班牙' , 
		'德国' , '泰国' , '印度' , '加拿大' , '澳大利亚' , '俄罗斯' , '波兰' , '丹麦' , '瑞典' , '巴西' , '墨西哥' , '阿根廷' ,
		'比利时' , '奥地利' , '荷兰' , '匈牙利' , '土耳其' , '希腊' , '爱尔兰' , '伊朗' , '捷克']
		
	filters['电视剧标签']=['美剧' , '英剧' , '韩剧' , '日剧' , '国产剧' , '港剧' , '台剧' , '泰剧' , '动漫']
	
	filters['年代标签']=['2014' , '2013' , '2012' , '2011' , '2010' , '2009' , '2008' , '2007' , '2006' ,
		'2005' , '2004' , '2003' , '2002' , '2001' , '2000' , '90s' , '80s' , '70s' , '60s' , '50s' , '40s' , '30s']
	curyear=int(time.strftime('%Y',time.localtime(time.time())))
	for intyear in range(2015,curyear+1):
		filters['年代标签'].insert(0, str(intyear))
		
	filters['自定义标签']=plugin.get_setting('dbdeftag').lower().split(',')
	
	sstr=''
	dialog = xbmcgui.Dialog()
	qtyps = ['类型标签','地区标签','电视剧标签','年代标签','自定义标签','手动输入']
	sel = dialog.select('标签类型', qtyps)
	if sel>=0:
		if sel==5:
			kb = Keyboard('',u'请输入标签,多个标签用空格隔开')
			kb.doModal()
			if not kb.isConfirmed(): return ''
			return kb.getText()
		else:
			sel2=dialog.select('标签类型',filters[qtyps[sel]])
			if sel2==-1: return ''
			return filters[qtyps[sel]][sel2]


@plugin.route('/dbmovie/<tags>/<sort>/<page>/<addtag>')
def dbmovie(tags='',sort='recommend',page=0,addtag=0):
	if tags=='0': tags=''
	if sort=='0': sort=''
	tag=''
	if int(addtag)==1:
		tag=dbgettag()
	taglist=[]
	if tags:
		taglist.extend(tags.split())
	if tag:
		taglist.extend(tag.split())
	if len(taglist)<1: return;
	tags=''
	for t in taglist:
		tags+=t+'%20'
	if not sort:
		dialog = xbmcgui.Dialog()
		sel = dialog.select('排序类型', ['按热度排序','按时间排序','按评分排序'])
		if sel==-1: return
		if sel==0: sort='recommend'
		if sel==1: sort='time'
		if sel==2: sort='rank'
	url='http://movie.douban.com/j/search_subjects?type=movie&tag=%s&sort=%s&page_limit=20&page_start=%s'%(tags,sort,str(page))
	
	
	try:
		rsp = _http(url)
		
		minfo = json.loads(rsp)
		menus =[]
		for m in minfo['subjects']:
			menus.append({'label': '%s[%s]'%(m['title'],m['rate']),
				'path': plugin.url_for('dbsubject', subject=m['id']),
				'thumbnail': m['cover'],
				})
			
		if not len(menus)>1: return
		if len(menus)==20:
			menus.append({'label': '下一页',
				'path': plugin.url_for('dbmovie',tags=tags,sort=sort,page=int(page)+20,addtag='0'),
				'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
		menus.insert(0, {'label': '继续标签过滤',
			'path': plugin.url_for('dbmovie',tags=tags,sort=sort,page='0',addtag='1')})
		menus.insert(0, {'label': '设置排序类型',
			'path': plugin.url_for('dbmovie',tags=tags,sort='0',page='0',addtag='0')})
		setthumbnail['set']=True
		return menus
	except:
		return


def rspmenus(rsp):
	menus=[]
	try:
		rtxt = r'tr class="item".*?nbg"\x20href="(.*?)".*?src="(.*?)"\x20alt="(.*?)".*?class="pl">(.*?)</p>.*?clearfix">(.*?)<span class="pl">'
		patt = re.compile(rtxt, re.S)
		mitems = patt.findall(rsp)
		if not mitems: return []
		
		for  s, i in enumerate(mitems):
			rating='-'
			if i[4].find('"rating_nums">')>0:
				rating=i[4][i[4].find('"rating_nums">')+14:i[4].rfind('</span>')]
			menus.append({'label': '{0}. {1}[{2}][{3}]'.format(s, i[2], rating, i[3]),
				 'path': plugin.url_for('dbsubject', subject=i[0][i[0].find('subject')+7:].replace('/','')),
				'thumbnail': i[1],})
				 #'thumbnail': i[1].replace('ipst','lpst').replace('img3.douban.com','img4.douban.com'),})
		return menus
	except:
		return []


@plugin.route('/dbactor/<sstr>/<page>')
def dbactor(sstr, page):
	urlpre = 'http://movie.douban.com/subject_search'
	if 'none' in sstr:
		kb = Keyboard('',u'请输入搜索关键字')
		kb.doModal()
		if not kb.isConfirmed(): return
		sstr = kb.getText()
	try:
		url = '%s?search_text=%s&start=%s' % (urlpre ,sstr, str(int(page)*15))
		rsp = _http(url)
		menus=rspmenus(rsp)
		count = re.findall(r'class="count">.*?(\d+).*?</span>', rsp)		
		count = int(count[0])
		page = int(page)		
		if (page+1)*15 < count:
			menus.append({
				'label': '下一页',
				'path': plugin.url_for('dbactor', sstr=sstr, page=page+1),
				'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8"),
				})
		setthumbnail['set']=True
		return menus
	except:return


@plugin.route('/dbntop')
def dbntop():
	try:
		rsp = _http('http://movie.douban.com/chart')
		menus=rspmenus(rsp)
		setthumbnail['set']=True
		return menus
	except:return

@plugin.route('/dbtop/<page>')
def dbtop(page):
	page = int(page)
	pc = page * 25
	try:
		rsp = _http('http://movie.douban.com/top250?start={0}'.format(pc))
		mstr = r'class="item".*?href="(.*?)".*?alt="(.*?)" src="(.*?)".*?<p class="">\s+(.*?)</p>'
		mpatt = re.compile(mstr, re.S)
		mitems = mpatt.findall(rsp)
		menus = [{'label': '{0}. {1}[{2}]'.format(s+pc+1, i[1], ''.join(
			i[3].replace('&nbsp;', ' ').replace('<br>', ' ').replace(
				'\n', ' ').split(' '))),
				  'path': plugin.url_for('dbsubject', subject=i[0][i[0].find('subject')+7:].replace('/','')),
				  'thumbnail': i[2],
				  #'thumbnail': i[2].replace('ipst','lpst').replace('img3.douban.com','img4.douban.com'),
			 } for s, i in enumerate(mitems)]

		if page <9 :
			menus.append({'label': '下一页',
						  'path': plugin.url_for('dbtop', page=page+1),
						  'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
		setthumbnail['set']=True
		return menus
	except:return


@plugin.route('/dbtypetop/<type>/<start>')
def dbtypetop(type='1',start=0):
	url='http://movie.douban.com/j/chart/top_list?type=%s&interval_id=100:90&action=&start=%s&limit=20'%(type,str(start))
	try:
		rsp = _http(url)
		
		minfo = json.loads(rsp)
		menus =[]
		for m in minfo:
			menus.append({'label': '%s[%s]'%(m['title'],m['score']),
				'path': plugin.url_for('dbsubject', subject=m['id']),
				'thumbnail': m['cover_url'],
				})
			
		if not len(menus)>1: return
		if len(menus)==20:
			menus.append({'label': '下一页',
				'path': plugin.url_for('dbtypetop',type=type,start=int(start)+20),
				'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
		
		setthumbnail['set']=True
		return menus
	except:
		return


javbusurl = plugin.get_storage('javbusurl')
@plugin.route('/javbus')
def javbus():
	urls=[]
	try:
		rsp = _http('https://about.me/javbus.com')
		#xbmc.log(rsp)
		urlitems=re.compile(r'(http|https)://([a-z0-9\x2E]*?)&lt', re.DOTALL).findall(rsp)
		urlbase=''
		rspbase=''
		
		for  s, url in enumerate(urlitems):
			try:
				urls.append(url[0]+'://'+url[1])
				#urls.append('http://'+url[1])
			except:
				continue
				
		if len(urls)<=0: urls.append('https://www.javbus.com/')
		
	except:
		plugin.notify('JAVBUS网址查询失败')
		#return	
		urls.append('https://www.javbus.me/')
		
	try:
		dialog = xbmcgui.Dialog()
		sel = dialog.select('网址选择', urls)
		if sel is -1: return
		javbusurl['base']=urls[sel]
		
		javbusurl['qb']=urls[sel]
		javbusurl['bb']=urls[sel]+'/uncensored'
		javbusurl['om']='https://www.javbus.xyz'
		#javbusurl['om']='http://www.javbus.xyz'
		rspbase=_http(javbusurl['base']+'/')
		match = re.search(r'visible-sm-block.*?href="([0-9a-zA-Z\x2E\x2F\x3A]*?)/">歐美', rspbase, re.DOTALL | re.MULTILINE)
		if match:
			javbusurl['om'] = match.group(1)
	except:
		javbusurl['om']='https://www.javbus.xyz'
		
	#plugin.notify(javbusurl['qb'])
	item = [
		{'label': '骑兵片片列表', 'path': plugin.url_for('javlist', qbbb='qb',filtertype='0',filterkey='0',page=1)},
		{'label': '骑兵优优列表', 'path': plugin.url_for('javstarlist', qbbb='qb',page=1)},
		{'label': '骑兵类别筛选', 'path': plugin.url_for('javgernefilter', qbbb='qb')},
		{'label': '骑兵中文片片', 'path': plugin.url_for('javlist', qbbb='qb',filtertype='genre',filterkey='sub',page=1)},
		{'label': '步兵片片列表', 'path': plugin.url_for('javlist', qbbb='bb',filtertype='0',filterkey='0',page=1)},
		{'label': '步兵优优列表', 'path': plugin.url_for('javstarlist', qbbb='bb',page=1)},
		{'label': '步兵类别筛选', 'path': plugin.url_for('javgernefilter', qbbb='bb')},
		{'label': '步兵中文片片', 'path': plugin.url_for('javlist', qbbb='bb',filtertype='genre',filterkey='sub',page=1)},
		{'label': '片片找找', 'path':  plugin.url_for('javlist', qbbb='qb',filtertype='search',filterkey='0',page=1)},
		{'label': '好雷屋片片列表', 'path': plugin.url_for('javlist', qbbb='om',filtertype='0',filterkey='0',page=1)},
		{'label': '好雷屋优优列表', 'path': plugin.url_for('javstarlist', qbbb='om',page=1)},
		{'label': '好雷屋类别筛选', 'path': plugin.url_for('javgernefilter', qbbb='om')},
	]
	return item
	
@plugin.route('/showpic/<imageurl>')
def showpic(imageurl):
	xbmc.executebuiltin("ShowPicture(%s)" % (imageurl))
	return 
	
@plugin.route('/javmagnet/<qbbb>/<gid>/<uc>')
def javmagnet(qbbb='qb',gid='0',uc='0'):
	menus=[]
	baseurl=javbusurl['base']
	if qbbb=='om':
		baseurl=javbusurl['om']
	try:
		rspmagnet=_http('%s/ajax/uncledatoolsbyajax.php?gid=%s&uc=%s&floor=1'%(baseurl,gid,uc),referer=baseurl)
		#xbmc.log(rspmagnet)
		leechmagnet = re.compile('onmouseover.*?href="(?P<magnet>magnet.*?)">\s*(?P<title>.*?)\s*</a>.*?href.*?">\s*(?P<filesize>.*?)\s*</a>.*?href.*?">\s*(?P<createdate>.*?)\s*</a>',  re.S)
		#if qbbb=='om':
		#	leechmagnet = re.compile(r'onmouseover.*?\x29">\s*(?P<title>.*?)\s*</td>.*?">\s*(?P<filesize>.*?)\s*</td>.*?">\s*(?P<createdate>.*?)\s*</td>.*?href="(?P<magnet>magnet.*?)">',  re.S)
		for match in leechmagnet.finditer(rspmagnet):
			magnet=match.group('magnet')
			title=match.group('title')
			title = re.sub("<a\x20.*?>", "|", title)
			filesize=match.group('filesize')
			createdate=match.group('createdate')

			filemsg ='大小：'+filesize.encode('UTF-8')+'  创建时间：'+createdate.encode('UTF-8')
			listitem=ListItem(label=colorize_label(title, 'bt'), label2=filesize.encode('UTF-8'), icon=None,
			thumbnail=xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8"), 
			path=plugin.url_for('offlinedown',url=magnet.encode('UTF-8'),title=title,msg=filemsg))
			menus.append(listitem)
		return menus
	except:
		plugin.notify('自带磁力获取失败')
		return

@plugin.route('/javdetail/<qbbb>/<movieno>/<id>/<title>')
def javdetail(qbbb='qb',movieno='0',id='0',title='0'):
	menus=[]
	url='%s/%s'%(javbusurl['base'],movieno)
	if qbbb=='om':
		url='%s/%s'%(javbusurl['om'],movieno)
	try:
		rsp = _http(url)
		match = re.search("var\x20gid\x20*=\x20*(?P<gid>.*?);.*?var\x20uc\x20=\x20(?P<uc>.*?);", rsp, re.DOTALL | re.MULTILINE)
		
		if match:
			gid = match.group('gid')
			uc = match.group('uc')
			if qbbb!='om':
				if uc=='0':qbbb='qb'
				if uc=='1':qbbb='bb'
			menus.append({'label': '[COLOR FF00FFFF]自带磁力[/COLOR]',
							'path': plugin.url_for('javmagnet', qbbb=qbbb, gid=gid,uc=uc),
							'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8")})
		menus.append({'label': 'BT:[COLOR FF00FFFF]%s[/COLOR]' % (id.encode('utf-8')),
							'path': plugin.url_for('btsearchInit', sstr=id.encode('utf-8'), modify='0'),
							'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8")})
		menus.append({'label': 'BT:[COLOR FF00FFFF]%s[/COLOR]' % (title.encode('utf-8')),
							'path': plugin.url_for('btsearchInit', sstr=title.encode('utf-8'), modify='0'),
							'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'magnet.jpg') ).decode("utf-8")})
		releech='"bigImage"\x20href="(?P<mainimg>.*?)"><'
		leech = re.compile(releech, re.S)
		for match in leech.finditer(rsp):
			menus.append({'label':'封面图',
				  'path': plugin.url_for('showpic', imageurl=match.group('mainimg')),
				  'thumbnail':match.group('mainimg'),})
				  
		releech='</span>\x20<a\x20href="%s/(?P<filter_type>[a-z]+?)/(?P<filter_key>[0-9a-z]+?)">(?P<filter_name>.*?)</a>'%(javbusurl[qbbb])
		leech = re.compile(releech, re.S)
		for match in leech.finditer(rsp):
			filtertype=''
			filterkey=match.group('filter_key')
			if filterkey and filterkey!='0':
				filtername=match.group('filter_name')
				if match.group('filter_type')=='director':
					filtertype= match.group('filter_type')
					filtertypename='导演'
				if match.group('filter_type')=='studio':
					filtertype= match.group('filter_type')
					filtertypename='制作商'
				if match.group('filter_type')=='label':
					filtertype= match.group('filter_type')
					filtertypename='发行商'
				if match.group('filter_type')=='series':
					filtertype= match.group('filter_type')
					filtertypename='系列'
				if filtertype:
					menus.append({'label':'%s:%s'%(filtertypename,filtername),
						  'path':plugin.url_for('javlist', qbbb=qbbb,filtertype=filtertype,filterkey=filterkey,page=1),
						  })
		releech='"genre"><a\x20href="%s/(?P<filter_type>[a-z]+?)/(?P<filter_key>[0-9a-z]+?)">(?P<filter_name>.*?)</a>'%(javbusurl[qbbb])
		
		
		leech = re.compile(releech, re.S)
		for match in leech.finditer(rsp):
			filtertype=''
			filterkey=match.group('filter_key')
			if filterkey and filterkey!='0':
				filtername=match.group('filter_name')
				if match.group('filter_type')=='genre':
					filtertype= match.group('filter_type')
					filtertypename='类别'
				if filtertype:
					menus.append({'label':'%s:%s'%(filtertypename,filtername),
						  'path':plugin.url_for('javlist', qbbb=qbbb,filtertype=filtertype,filterkey=filterkey,page=1),
						  })
		releech='avatar-box.*?href="%s/star/(?P<starid>.*?)">.*?src="(?P<starimg>.*?)".*?<span>(?P<starname>.*?)</span>'%(javbusurl[qbbb])
		if qbbb=='om':
			releech='href="%s/star/(?P<starid>[0-9a-z]{1,10}?)"\s*?target="_blank"><img\s*?src="(?P<starimg>.*?)".*?title.*?title.*?_blank">(?P<starname>.*?)</a>'%(javbusurl[qbbb])
		leech = re.compile(releech, re.S)
		for match in leech.finditer(rsp):
			menus.append({'label':'优优:%s'%(match.group('starname')),
					  'path':plugin.url_for('javlist', qbbb=qbbb,filtertype='star',filterkey=match.group('starid'),page=1),
					  'thumbnail':match.group('starimg'),})
		releech='sample-box.*?href="(?P<sampleimg>.*?)">.*?src="(?P<thumbimg>.*?)"'
		if qbbb=='om':
			releech='href="(?P<sampleimg>[^"]*?.jpg)"><img\x20src="(?P<thumbimg>[^"]*?thumb.jpg)"'
		leech = re.compile(releech, re.S)
		for match in leech.finditer(rsp):
			menus.append({'label':'样品图',
				  'path': plugin.url_for('showpic', imageurl=match.group('sampleimg')),
				  'thumbnail':match.group('thumbimg'),})
		setthumbnail['set']=True
		return menus
	except:
		plugin.notify('片片信息获取失败')
		return

@plugin.route('/javlist/<qbbb>/<filtertype>/<filterkey>/<page>')
def javlist(qbbb='qb',filtertype='0',filterkey='0',page=1):

	filter=''
	if filtertype!='0':
		if filterkey!='0':
			filter='/%s/%s'%(filtertype,filterkey)
		
		else:
			if filtertype=='search':
				kb = Keyboard('',u'请输入搜索关键字')
				kb.doModal()
				if not kb.isConfirmed():return
				filterkey = kb.getText()
				filter='/%s/%s'%(filtertype,filterkey)
			else:
				filter='/'+filtertype
	pagestr=''
	if int(page)>1:
		if filter:
			pagestr='/'+str(page)
		else:
			pagestr='/page/'+str(page)
	url='%s%s%s'%(javbusurl[qbbb],filter,pagestr)
	#xbmc.log(url)
	try:
		rsp = _http(url)
		releech='movie-box.*?href="(?P<detailurl>.*?)".*?src="(?P<imageurl>.*?)".*?title="(?P<title>.*?)".*?<date>(?P<id>.*?)</date>.*?<date>(?P<date>.*?)</date>'
		# if qbbb=='om':
			# releech='"item pull-left".*?href="(?P<detailurl>.*?)".*?src="(?P<imageurl>.*?)".*?"_blank">(?P<title>.*?)</a><br>.*?"item-title">(?P<id>.*?)</span>.*?"item-title">(?P<date>.*?)</span>'
		leech = re.compile(releech, re.S)
		menus=[]
		for match in leech.finditer(rsp):
			detailurl=match.group('detailurl')
			movieno=detailurl[detailurl.rfind('/')+1:]
			menus.append({'label':'[[COLOR FFFFFF00]%s[/COLOR]]%s(%s)'%(match.group('id'), match.group('title'), match.group('date')),
				  'path': plugin.url_for('javdetail',qbbb=qbbb, movieno=movieno,id=match.group('id'),title=match.group('title')),
				  'thumbnail':match.group('imageurl'),})
		strnextpage=str(int(page)+1)
		strnextpage='/'+strnextpage+'">'+strnextpage+'</a>'
		if rsp.find(strnextpage)>=0:
			menus.append({'label': '下一页',
						'path':plugin.url_for('javlist', qbbb=qbbb,filtertype=filtertype,filterkey=filterkey,page=int(page)+1),
						'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
		setthumbnail['set']=True
		return menus
	except:
		plugin.notify('片片列表获取失败')
		return

@plugin.route('/javstarlist/<qbbb>/<page>')
def javstarlist(qbbb='qb',page=1):
	filter='/actresses'
	pagestr=''
	if int(page)>1:		
		pagestr='/'+str(page)
	url='%s%s%s'%(javbusurl[qbbb],filter,pagestr)
	try:
		rsp = _http(url)
		releech='avatar-box.*?href="%s/star/(?P<starid>.*?)">.*?src="(?P<starimg>.*?)".*?<span>(?P<starname>.*?)</span>'%(javbusurl[qbbb])		
		# if qbbb=='om':
			# releech=r'star-frame2.*?href="%s/star/(?P<starid>.*?)".*?src="(?P<starimg>.*?)".*?title="(?P<starname>.*?)"'%(javbusurl[qbbb])
		leech = re.compile(releech, re.S)
		menus=[]
		for match in leech.finditer(rsp):
			menus.append({'label':'优优:%s'%(match.group('starname')),
					  'path':plugin.url_for('javlist', qbbb=qbbb,filtertype='star',filterkey=match.group('starid'),page=1),
					  'thumbnail':match.group('starimg'),})
		strnextpage=str(int(page)+1)
		strnextpage='/'+strnextpage+'">'+strnextpage+'</a>'
		if rsp.find(strnextpage)>=0:
			menus.append({'label': '下一页',
						'path':plugin.url_for('javstarlist', qbbb=qbbb,page=int(page)+1),
						'thumbnail':xbmc.translatePath( os.path.join( __cwd__, 'nextpage.jpg') ).decode("utf-8")})
		setthumbnail['set']=True
		return menus
	except:
		plugin.notify('女优列表获取失败')
		return
	
@plugin.route('/javgerne/<qbbb>')
def javgernefilter(qbbb='qb'):
	url=javbusurl[qbbb]+'/genre'
	
	try:
		rsp = _http(url)
		menus=[]
		
		#if qbbb!='om':
		releech='<h4>(?P<genregroup>.*?)</h4>.*?"row genre-box">(?P<genres>.*?)</div>'
		leech = re.compile(releech, re.S)
		
		genrelist={}
		genregrouplist=[]
		for match in leech.finditer(rsp):
			genrelist[match.group('genregroup')]= match.group('genres')
			genregrouplist.append(match.group('genregroup'))
		
		dialog = xbmcgui.Dialog()
		
		sel = dialog.select('类别模式', genregrouplist)
		if sel is -1: return
		genres=genrelist[genregrouplist[sel]]
		#else:
		#	genres=rsp
		releech = 'href="%s/genre/(?P<genreid>.+?)">(?P<genrename>.+?)</a>'%(javbusurl[qbbb])
		leech = re.compile(releech, re.S)
		for match in leech.finditer(genres):
			menus.append({'label':match.group('genrename'),
				  'path':plugin.url_for('javlist', qbbb=qbbb,filtertype='genre',filterkey=match.group('genreid'),page=1),
				  })
		return menus
	except:
		plugin.notify('类型列表获取失败')
		return
   
def is_video(ext):
	return ext.lower() in ['mkv', 'mp4', 'm4v', 'mov', 'flv', 'wmv', 'asf', 'avi', 'm2ts', 'mts', 'm2t', 'ts', 'mpg', 'mpeg', '3gp', 'rmvb', 'rm', 'iso']

def is_ext_video(ext):
	return ext.lower() in ['iso', 'm2ts', 'mts', 'm2t']

def is_subtitle(ext):
	return ext.lower() in ['srt', 'sub', 'ssa', 'smi', 'ass']

def is_audio(ext):
	return ext.lower() in ['wav', 'flac', 'mp3', 'ogg', 'm4a', 'ape', 'dff', 'dsf', 'wma', 'ra']

def is_image(ext):
	return ext.lower() in ['jpg', 'jpeg', 'bmp', 'tif', 'tiff', 'png', 'gif']

class Player(xbmc.Player):

	def play(self, item='', listitem=None, windowed=False, sublist=None):
		self._sublist = sublist

		super(Player, self).play(item, listitem, windowed)

		self._start_time = time.time()
		while True:
			# print self._start_time, time.time()
			if self._stopped or time.time() - self._start_time > 300:
				if self._totalTime == 999999:
					raise PlaybackFailed(
						'XBMC silently failed to start playback')
				break

			xbmc.sleep(500)
		# print 'play end'

	def __init__(self):
		self._stopped = False
		self._totalTime = 999999

		xbmc.Player.__init__(self, xbmc.PLAYER_CORE_AUTO)

	def onPlayBackStarted(self):
		self._totalTime = self.getTotalTime()
		self._start_time = time.time()

		sublist = self._sublist
		if sublist:
			if isinstance(sublist, basestring):
				sublist = [sublist]

			for surl in sublist:
				# print '$'*50, surl
				self.setSubtitles(surl)
			self.setSubtitleStream(0)
			# self.showSubtitles(False)

	def onPlayBackStopped(self):
		self._stopped = True

	def onPlayBackEnded(self):
		self.onPlayBackStopped()


class PlaybackFailed(Exception):

	'''Raised to indicate that xbmc silently failed to play the stream'''


def colorize_label(label, _class=None, color=None):
	color = color or colors.get(_class)

	if not color:
		return label

	if len(color) == 6:
		color = 'FF' + color

	return '[COLOR %s]%s[/COLOR]' % (color, label)

#plugin.notify(plugin.url_for('deletefile',pid='cid',fid='fid'))
if __name__ == '__main__':
	# Override default handler
	
	plugin.run()
	skindir=xbmc.getSkinDir()
	if setthumbnail['set']:
		if ALL_VIEW_CODES['thumbnail'].has_key(skindir):		
			plugin.set_view_mode(ALL_VIEW_CODES['thumbnail'][skindir])