# -*- coding: utf-8 -*-
#VERSION: 1.00

from novaprinter import prettyPrinter
from helpers import retrieve_url, download_file
import json,urllib,re,xbmc,xbmcgui

from xbmcswift2 import Plugin
plugin=Plugin()
class btbook(object):
	url = 'http://www.btbook.net/search/'
	name = 'btbook'
	supported_categories = {'all': ''}

	def __init__(self):
		pass
		
	def search(self, what, cat='all',sorttype='-1',page='1'): 	
		result={}
		result['state']=False
		result['list']=[]
		
		if str(sorttype)=='-1':
			dialog = xbmcgui.Dialog()
			sorttype=dialog.select('btbook搜索-选择排序类型',['创建时间','文件大小','下载热度','相关度'])
			if sorttype==-1:
				return result
			sorttype=str(sorttype+1)
		result['sorttype']=sorttype
		searchurl=self.url+'%s/%s-%s.html'%(urllib.quote(what),str(int(page)),str(sorttype))
		#plugin.notify(searchurl)
		try:
			pageresult = retrieve_url(searchurl)
			#xbmc.log(msg=pageresult)
			rmain=r'target="_blank">(?P<title>.*?)</a>.*?<ul>(?P<filelist>.*?)</ul>.*?fileType[0-9]*?">(?P<filetype>.*?)</span>.*?创建时间.*?<b.*?>(?P<createtime>.*?)</b>.*?文件大小.*?<b.*?>(?P<filesize>.*?)</b>.*?下载热度.*?<b.*?>(?P<heatlevel>.*?)</b>.*?最近下载.*?<b.*?>(?P<lastdown>.*?)</b>.*?href="(?P<magnet>.*?)"'
			reobj = re.compile(rmain, re.DOTALL)
			for match in reobj.finditer(pageresult):
				title=match.group('title')
				#plugin.notify(title)
				filesize=match.group('filesize')
				createtime=match.group('createtime')
				title=title.replace('<b>','').replace('</b>','')
				magnet=match.group('magnet')
				
				res_dict = dict()
				res_dict['name'] = title
				res_dict['size'] = filesize
				res_dict['seeds'] = ''
				res_dict['leech'] = ''
				res_dict['link'] = magnet
				res_dict['date'] =createtime
				res_dict['desc_link'] = ''
				res_dict['engine_url'] = self.url
				result['list'].append(res_dict)
			if len(result['list'])>0:
				result['nextpage']=True
		except:
			return result
		
		result['state']=True
		return result