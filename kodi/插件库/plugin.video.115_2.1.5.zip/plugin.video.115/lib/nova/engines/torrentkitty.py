# -*- coding: utf-8 -*-
#VERSION: 1.28
#AUTHORS: Christophe Dumez (chris@qbittorrent.org)
#CONTRIBUTORS: Diego de las Heras (diegodelasheras@gmail.com)

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#    * Neither the name of the author nor the names of its contributors may be
#      used to endorse or promote products derived from this software without
#      specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from novaprinter import prettyPrinter
from helpers import retrieve_url, download_file
import json,urllib,xbmc,re

class torrentkitty(object):
	url = 'http://www.torrentkitty.net/search/'
	name = 'torrentkitty'
	supported_categories = {'all': ''}

	def __init__(self):
		pass

	def download_torrent(self, info):
		print download_file(info, info)

	def search(self, what, cat='all',sorttype='-1',page=1):
		result={}
		result['state']=False
		result['list']=[]
		searchurl=self.url+'%s/%s'%(what,str(int(page)))
		try:
			pageresult = retrieve_url(searchurl)
			
			rmain=r'<td class="name">(?P<title>.*?)</td><td class="size">(?P<filesize>.*?)</td><td class="date">(?P<createtime>.*?)</td>.*?<a href="(?P<magnet>magnet.*?)&tr='
			reobj = re.compile(rmain, re.DOTALL)
			xbmc.log(msg=rmain)
			for match in reobj.finditer(pageresult):				
				title=match.group('title')
				filesize=match.group('filesize')
				createtime=match.group('createtime')				
				magnet=match.group('magnet')
				xbmc.log(msg=magnet)
				res_dict = dict()
				res_dict['name'] = title.encode('UTF-8')
				res_dict['size'] = '种子'+filesize
				res_dict['seeds'] = ''
				res_dict['leech'] = ''
				res_dict['link'] = magnet
				res_dict['date'] =createtime
				res_dict['desc_link'] = ''
				res_dict['engine_url'] = self.url
				result['list'].append(res_dict)
				
			if  pageresult.find('<a href="%s">%s</a>'%(str(int(page)+1),str(int(page)+1)))>0:
				result['nextpage']=True
		except:
			return result
		
		result['state']=True
		return result
	  